# 安装k8s



## 安装docker

1. 换源

   ``` bash
   curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
   ```

2. 安装

   ``` bash
   curl -sSL https://get.daocloud.io/docker | sh
   systemctl enable --now docker
   ```

3. 换源

   ``` bash
   vim /etc/docker/daemon.json
   {
     "registry-mirrors": ["http://hub-mirror.c.163.com"],
     "exec-opts": ["native.cgroupdriver=systemd"]
   }
   systemctl restart docker
   ```

   

## 安装kubelet

https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/

1. 换源：

    ``` bash
    cat <<EOF | sudo tee /etc/yum.repos.d/kubernetes.repo
    [kubernetes]
    name=Kubernetes
    baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-\$basearch
    enabled=1
    gpgcheck=1
    repo_gpgcheck=1
    gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
    exclude=kubelet kubeadm kubectl
    EOF
    ```

    ``` bash
    yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
    systemctl enable --now kubelet
    ```

2. 镜像预载（注意更改版本号）

    https://blog.51cto.com/3241766/2405624

    ``` bash
    #!/bin/bash
    url=registry.cn-hangzhou.aliyuncs.com/google_containers
    version=v1.14.2
    images=(`kubeadm config images list --kubernetes-version=$version|awk -F '/' '{print $2}'`)
    for imagename in ${images[@]} ; do
      docker pull $url/$imagename
      docker tag $url/$imagename k8s.gcr.io/$imagename
      docker rmi -f $url/$imagename
    done
    ```

3. 初始化

    ``` bash
    kubeadm init --apiserver-advertise-address 192.168.6.91 --pod-network-cidr=10.244.0.0/16
    echo "export KUBECONFIG=/etc/kubernetes/admin.conf" >> ~/.bash_profile
    source ~/.bash_profile
    ```

4. 切换DNS

    ``` bash
    vim /etc/resolv.conf
    nameserver 180.76.76.76
    ```

5. 安装pod网络

   ``` bash
   kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
   ```


