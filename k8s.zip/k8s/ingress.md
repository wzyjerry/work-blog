nginx.org/client-max-body-size: "0"

kubernetes.io/ingress.class: "nginx"